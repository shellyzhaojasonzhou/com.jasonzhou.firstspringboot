package com.demo;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;

import com.aspose.slides.License;
import com.aspose.slides.Presentation;
import com.aspose.slides.SaveFormat;

/**
 * 
 * 由于ASPOSE比较吃内存，操作大一点的文件就会堆溢出，所以请先设置好java虚拟机参数：-Xms512m -Xmx512m(参考值)<br>
 * 
 * 如有疑问，请在CSDN下载界面留言，或者联系QQ569925980<br>
 * 
 * @author Spark
 *
 */
public class TestSlides {

    private static InputStream license;
    private static InputStream slides;

    /**
     * 获取license
     * 
     * @return
     */
    public static boolean getLicense() {
        boolean result = false;
        try {
            license = TestSlides.class.getClassLoader().getResourceAsStream("\\license.xml");   // license路径
            slides = TestSlides.class.getClassLoader().getResourceAsStream("\\test.ppt");   // 原始ppt路径
            License aposeLic = new License();
            aposeLic.setLicense(license);
            result = true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return result;
    }

    /**
     * 
     * @param args
     */
    public static void main(String[] args) {
        // 验证License
        if (!getLicense()) {
            return;
        }
        try {
            long old = System.currentTimeMillis();
            Presentation pres = new Presentation(slides);
            File file = new File("D:\\test.pdf");// 输出pdf路径
            FileOutputStream fileOS = new FileOutputStream(file);

            pres.save(fileOS, SaveFormat.Pdf);

            long now = System.currentTimeMillis();
            System.out.println("共耗时：" + ((now - old) / 1000.0) + "秒\n\n" + "文件保存在:" + file.getPath());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}